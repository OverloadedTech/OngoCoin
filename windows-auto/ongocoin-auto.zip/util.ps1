Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=d135531935d1d5775f302b4906a10552810a488f1734462d1d&filename=ongocoin-qt-windows.zip" -OutFile "$HOME\Downloads\ongocoin-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\ongocoin-qt-windows.zip" -DestinationPath "$HOME\Desktop\OngoCoin"

$ConfigFile = "rpcuser=rpc_ongocoin
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=0.0.0.0
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node2.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "OngoCoin" -ItemType "directory"
New-Item -Path "$env:appdata\OngoCoin" -Name "OngoCoin.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('ongocoin-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 ongocoin-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\OngoCoin" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\OngoCoin\ongocoin-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\OngoCoin\"
Start-Process "mine.bat"